package edu.kpi.components;

import com.jpmorrsn.fbp.engine.Component;
import com.jpmorrsn.fbp.engine.ComponentDescription;
import com.jpmorrsn.fbp.engine.InPort;
import com.jpmorrsn.fbp.engine.InputPort;
import com.jpmorrsn.fbp.engine.OutPort;
import com.jpmorrsn.fbp.engine.OutputPort;
import com.jpmorrsn.fbp.engine.Packet;

import edu.kpi.fbp.network.datastucts.NamedArray;
import edu.kpi.fbp.network.datastucts.NamedValue;

@ComponentDescription("This component gets average value of named array items.")
@InPort(value = Average.PORT_IN, type = NamedArray.class)
@OutPort(value = Average.PORT_OUT, type = NamedValue.class)
public class Average extends Component {

  public static final String PORT_IN = "IN";
  public static final String PORT_OUT = "OUT";

  private InputPort inPort;
  private OutputPort outPort;

  @SuppressWarnings("unchecked")
  @Override
  protected void execute() throws Exception {
    Packet<NamedArray<Float>> pack;
    while ((pack = inPort.receive()) != null) {
      final NamedArray<Float> arr = pack.getContent();
      drop(pack);

      Double sum = 0d;
      int nullValues = 0;
      for (final Float d : arr) {
        if (d == null) {
          nullValues++;
        } else {
          sum += d;
        }
      }

      final String columnName = arr.getName();
      final Float aver = new Float(sum / (arr.size() - nullValues));

      final NamedValue<Float> res = new NamedValue<Float>() {
        public String getName() {
          return columnName;
        }

        public Float getValue() {
          return aver;
        }

        @Override
        public String toString() {
          return getName() + " " + getValue();
        }
      };

      outPort.send(create(res));
    }

//    outPort.close();
  }
  @Override
  protected void openPorts() {
    inPort = openInput(PORT_IN);
    outPort = openOutput(PORT_OUT);
  }

}
