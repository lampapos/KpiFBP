package edu.kpi.fbp.network.components;

import com.jpmorrsn.fbp.engine.Component;
import com.jpmorrsn.fbp.engine.InPort;
import com.jpmorrsn.fbp.engine.InputPort;
import com.jpmorrsn.fbp.engine.Packet;

@InPort(value = TestComponent.IN_PORT)
public class TestComponent extends Component {

  public static final String IN_PORT = "IN";

  private static Object result;

  private InputPort inPort;

  @Override
  protected void execute() throws Exception {
    final Packet<?> pack = inPort.receive();
    result = pack.getContent();
    drop(pack);
    inPort.close();
  }

  @Override
  protected void openPorts() {
    inPort = openInput(IN_PORT);
  }

  public static Object getResult() {
    return result;
  }

}
