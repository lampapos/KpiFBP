package edu.kpi.fbp.network.components;

import java.util.ArrayList;

import org.junit.Assert;
import org.junit.Test;

import com.jpmorrsn.fbp.engine.Network;

import edu.kpi.components.Average;
import edu.kpi.fbp.network.datastucts.NamedArray;
import edu.kpi.fbp.network.datastucts.NamedValue;

public class AverageTest {

  @SuppressWarnings("unchecked")
  @Test
  public void testOne() throws Exception {
    final NamedList list = new NamedList();
    list.add(1.0f);
    list.add(1.0f);
    list.add(1.0f);
    list.add(1.0f);
    list.add(1.0f);
    list.add(1.0f);
    list.add(1.0f);

    new TestNetwork(list).go();
    Thread.sleep(1000);
    Assert.assertEquals(1f, ((NamedValue<Float>) TestComponent.getResult()).getValue(), 0.00001f);
  }

  @SuppressWarnings("unchecked")
  @Test
  public void testTwo() throws Exception {
    final NamedList list = new NamedList();
    list.add(1.0f);
    list.add(2.0f);
    list.add(3.0f);
    list.add(4.0f);
    list.add(5.0f);
    list.add(6.0f);
    list.add(7.0f);
    list.add(8.0f);
    list.add(9.0f);
    list.add(10.0f);

    new TestNetwork(list).go();
    Thread.sleep(1000);
    Assert.assertEquals(5.5f, ((NamedValue<Float>) TestComponent.getResult()).getValue(), 0.00001f);
  }

  @SuppressWarnings("serial")
  public static class NamedList extends ArrayList<Float> implements NamedArray<Float> {
    public String getName() {
      return "";
    }
  }

  public static class TestNetwork extends Network {

    private final NamedArray<Float> inArray;

    public TestNetwork(final NamedArray<Float> inArray) {
      this.inArray = inArray;
    }

    @Override
    protected void define() throws Exception {
      component("Average", Average.class);
      component("Test", TestComponent.class);

      initialize(inArray, "Average.IN");
      connect("Average.OUT", "Test.IN");
    }

  }

}
